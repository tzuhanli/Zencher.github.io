

let tello:Tello = Tello()



tello.takeOff()

tello.left(distance: 100)
tello.right(distance: 100)

tello.flipForward()

tello.rotateClockwise(degree:90)
tello.rotateCounterClockwise(degree:90)

tello.land()
